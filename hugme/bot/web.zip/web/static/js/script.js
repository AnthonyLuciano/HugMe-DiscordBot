document.addEventListener('DOMContentLoaded', () => {
    console.log('Painel administrativo carregado!');
    // Adicione interações aqui (ex: filtros, atualizações via API)
});